{{imports}}
{{plugins}}

kotlin {
{{kotlin_targets}}
{{sourcesets}}
}

{{configuration_blocks}}
